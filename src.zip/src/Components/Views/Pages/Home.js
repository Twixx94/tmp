import React from 'react'

export const Home = () => {
  return (
    <div>
        <h2>Welcome</h2>
    </div>
  )
}
